<?php

namespace App\Http\Controllers;

use Illuminate\Http\Request;
use Illuminate\Support\Facades\Auth;
use Illuminate\Support\Facades\Hash;
use App\Models\Admin;
// use Illuminate\Support\Facades\View;        // tambahkan ini
// use Illuminate\Support\Facades\Redirect;    // tambahkan ini
// use Illuminate\Support\Facades\Response;    // tambahkan ini

class AuthController extends Controller
{
    public function showRegister() {
        return view('auth.register');
    }

   public function register(Request $request) {
    $request->validate([
        'name' => 'required',
        'email' => 'required|email|unique:admins,email', // Diubah ke unique:admins,email
        'password' => 'required|min:6|confirmed',
    ]);

    Admin::create([
        'name' => $request->name,
        'email' => $request->email,
        'password' => Hash::make($request->password),
        // 'role' => 'admin' // Hapus atau pastikan kolom 'role' ada di tabel 'admins'
    ]);

    return redirect()->route('login')->with('success', 'Registrasi berhasil. Silakan login.');
}
    public function showLogin() {
        return view('auth.login');
    }

    public function login(Request $request) {
        $request->validate([
            'email' => 'required|email',
            'password' => 'required|min:6',
        ], [
            'email.required' => 'Email wajib diisi.',
            'email.email' => 'Format email tidak valid.',
            'password.required' => 'Password wajib diisi.',
            'password.min' => 'Password minimal 6 karakter.',
        ]);
    
        if (Auth::attempt(['email' => $request->email, 'password' => $request->password])) {
            return redirect()->route('dashboard');
        }
    
        return back()->with('error', 'Email atau password salah.')->withInput();
    }
    

    public function logout() {
        Auth::logout();
        return redirect()->route('login');
    }
}
