<?php $__env->startSection('title', 'Daftar Guru'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Daftar Guru</h2>
    <a href="<?php echo e(route('teachers.create')); ?>" class="btn btn-primary mb-3">Tambah Guru</a>

    <!-- Form Pencarian -->
    <form method="GET" action="<?php echo e(route('teachers.index')); ?>" class="mb-3">
        <div class="row">
            <div class="col-md-4">
                <select name="gender" class="form-control">
                    <option value="">Pilih Gender</option>
                    <option value="1" <?php echo e(request('gender') == '1' ? 'selected' : ''); ?>>Laki-Laki</option>
                    <option value="0" <?php echo e(request('gender') == '0' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>
            <div class="col-md-4">
                <input type="text" name="subject" class="form-control" placeholder="Cari Mata Pelajaran" value="<?php echo e(request('subject')); ?>">
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-success">Cari</button>
                <a href="<?php echo e(route('teachers.index')); ?>" class="btn btn-secondary">Reset</a>
            </div>
        </div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>NIP</th>
                <th>Nama</th>
                <th>Jenis Kelamin</th>
                <th>Email</th>
                <th>Mata Pelajaran</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $teachers; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $teacher): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($teacher->nip); ?></td>
                <td><?php echo e($teacher->name); ?></td>
                <td><?php echo e($teacher->gender ? 'Laki-Laki' : 'Perempuan'); ?></td>
                <td><?php echo e($teacher->email); ?></td>
                <td><?php echo e($teacher->subject); ?></td>
                <td><?php echo e($teacher->address); ?></td>
                <td>
                    <a href="<?php echo e(route('teachers.edit', $teacher->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('teachers.destroy', $teacher->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\e-form (dah bagus api)\e-form\resources\views/teachers/index.blade.php ENDPATH**/ ?>