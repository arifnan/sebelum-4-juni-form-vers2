<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title><?php echo $__env->yieldContent('title'); ?></title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.3.0/dist/css/bootstrap.min.css" rel="stylesheet">
    <link href="<?php echo e(asset('css/auth-style.css')); ?>" rel="stylesheet">
</head>
<body>
    <div class="auth-container">
        <div class="auth-left"></div>
        <div class="auth-right">
            <?php echo $__env->yieldContent('content'); ?>
        </div>
    </div>
</body>
</html>
<?php /**PATH C:\laragon\www\e-form (dah bagus api)\e-form\resources\views/layouts/auth-layout.blade.php ENDPATH**/ ?>