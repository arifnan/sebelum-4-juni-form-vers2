<?php $__env->startSection('title', 'Daftar Siswa'); ?>

<?php $__env->startSection('content'); ?>
<div class="container mt-4">
    <h2>Daftar Siswa</h2>
    <a href="<?php echo e(route('students.create')); ?>" class="btn btn-primary mb-3">Tambah Siswa</a>

    <!-- Form Pencarian -->
    <form method="GET" action="<?php echo e(route('students.index')); ?>" class="mb-3">
        <div class="row">
            <div class="col-md-4">
                <select name="gender" class="form-control">
                    <option value="">Pilih Gender</option>
                    <option value="1" <?php echo e(request('gender') == '1' ? 'selected' : ''); ?>>Laki-Laki</option>
                    <option value="0" <?php echo e(request('gender') == '0' ? 'selected' : ''); ?>>Perempuan</option>
                </select>
            </div>
            <div class="col-md-4">
                <select name="grade" class="form-control">
                    <option value="">Pilih Kelas</option>
                    <option value="10" <?php echo e(request('grade') == '10' ? 'selected' : ''); ?>>10</option>
                    <option value="11" <?php echo e(request('grade') == '11' ? 'selected' : ''); ?>>11</option>
                    <option value="12" <?php echo e(request('grade') == '12' ? 'selected' : ''); ?>>12</option>
                </select>
            </div>
            <div class="col-md-4">
                <button type="submit" class="btn btn-success">Cari</button>
                <a href="<?php echo e(route('students.index')); ?>" class="btn btn-secondary">Reset</a>
            </div>
        </div>
    </form>

    <table class="table table-bordered">
        <thead>
            <tr>
                <th>#</th>
                <th>Nama</th>
                <th>Jenis Kelamin</th>
                <th>Email</th>
                <th>Kelas</th>
                <th>Alamat</th>
                <th>Aksi</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $students; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $student): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($loop->iteration); ?></td>
                <td><?php echo e($student->name); ?></td>
                <td><?php echo e($student->gender ? 'Laki-Laki' : 'Perempuan'); ?></td>
                <td><?php echo e($student->email); ?></td>
                <td><?php echo e($student->grade); ?></td>
                <td><?php echo e($student->address); ?></td>
                <td>
                    <a href="<?php echo e(route('students.edit', $student->id)); ?>" class="btn btn-warning btn-sm">Edit</a>
                    <form action="<?php echo e(route('students.destroy', $student->id)); ?>" method="POST" class="d-inline">
                        <?php echo csrf_field(); ?>
                        <?php echo method_field('DELETE'); ?>
                        <button type="submit" class="btn btn-danger btn-sm" onclick="return confirm('Yakin ingin menghapus?')">Hapus</button>
                    </form>
                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', array_diff_key(get_defined_vars(), ['__data' => 1, '__path' => 1]))->render(); ?><?php /**PATH C:\laragon\www\e-form (dah bagus api)\e-form\resources\views/students/index.blade.php ENDPATH**/ ?>